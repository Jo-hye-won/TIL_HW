for i in range(2,10):
    for j in range(1,10):
        print(f'{i} * {j} = {i*j}')